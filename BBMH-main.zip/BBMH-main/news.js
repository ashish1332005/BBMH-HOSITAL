gsap.from(".news-item img",{
        scale:0,
        duration:1,
        stagger : 0.11,
});
